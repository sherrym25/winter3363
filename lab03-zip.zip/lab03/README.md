# Lab 03 - Forms + Sessions (Login/Logout)

## Features
- Login form with server-side validation
- PHP sessions store login state
- Protected page (dashboard.php) requires login
- Logout destroys session

## Demo credentials
- Username: student
- Password: Lab03!
