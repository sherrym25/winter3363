<?php
/*
  Lab 04 Documentation Page (Updated for your lab04_demo database)

  Notes:
  - This page documents the database you created in phpMyAdmin.
  - Update Name/Date below if needed.
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lab 04 - MySQL Fundamentals Documentation</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }
    h1, h2, h3 { margin-bottom: 6px; }
    .meta { margin-top: 0; color: #333; }
    code { background: #f3f3f3; padding: 2px 6px; border-radius: 4px; }
    pre { background: #f3f3f3; padding: 12px; border-radius: 6px; overflow-x: auto; }
    ul { margin-top: 6px; }
    .section { margin-top: 18px; }
    table { border-collapse: collapse; width: 100%; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background: #f3f3f3; }
    .note { color: #444; }
  </style>
</head>
<body>

  <h1>Lab 04: MySQL Fundamentals (phpMyAdmin)</h1>

  <p class="meta">
    <strong>Name:</strong> Sherry Ma<br>
    <strong>Date:</strong> 2026-01-04
  </p>

  <div class="section">
    <h2>Database</h2>
    <p>
      <strong>Database name:</strong> <code>lab04_demo</code>
    </p>
  </div>

  <div class="section">
    <h2>Tables and Purpose</h2>
    <ul>
      <li><strong>customers</strong> — Stores customer contact information (one row per customer).</li>
      <li><strong>orders</strong> — Stores orders (one row per order) and links each order to a customer using <code>customer_id</code>.</li>
    </ul>
  </div>

  <div class="section">
    <h2>Table Fields (Columns)</h2>

    <h3>customers</h3>
    <ul>
      <li><code>customer_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
      <li><code>first_name</code> — VARCHAR(50)</li>
      <li><code>last_name</code> — VARCHAR(50)</li>
      <li><code>email</code> — VARCHAR(100)</li>
    </ul>

    <h3>orders</h3>
    <ul>
      <li><code>order_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
      <li><code>customer_id</code> — INT (matches <code>customers.customer_id</code>)</li>
      <li><code>order_date</code> — DATE</li>
      <li><code>total_amount</code> — DECIMAL(8,2)</li>
      <li><code>status</code> — VARCHAR(20)</li>
    </ul>

    <p class="note">
      Note: The <code>orders.customer_id</code> field connects each order to a specific customer in the <code>customers</code> table.
    </p>
  </div>

  <div class="section">
    <h2>Sample Data Inserted</h2>

    <h3>Customers (3 rows)</h3>
    <table>
      <thead>
        <tr>
          <th>Customer</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Alice Wong</td>
          <td>alicew@example.com</td>
        </tr>
        <tr>
          <td>Mike Dong</td>
          <td>miked@example.com</td>
        </tr>
        <tr>
          <td>Sam Berth</td>
          <td>samb@example.com</td>
        </tr>
      </tbody>
    </table>

    <h3>Orders (3 rows)</h3>
    <p class="note">
      These orders were inserted with valid <code>customer_id</code> values that match existing customers.
    </p>
    <table>
      <thead>
        <tr>
          <th>Order Date</th>
          <th>Total Amount</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>2026-01-04</td>
          <td>49.99</td>
          <td>paid</td>
        </tr>
        <tr>
          <td>2026-01-03</td>
          <td>19.50</td>
          <td>pending</td>
        </tr>
        <tr>
          <td>2026-01-02</td>
          <td>120.00</td>
          <td>paid</td>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2>Sample SQL Queries</h2>
    <p>These queries were run in phpMyAdmin using the SQL tab.</p>

    <pre><code>SELECT * FROM customers;</code></pre>

    <pre><code>SELECT * FROM orders
ORDER BY total_amount DESC;</code></pre>

    <pre><code>SELECT c.customer_id, c.first_name, c.last_name, c.email,
       o.order_id, o.order_date, o.total_amount, o.status
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;</code></pre>
  </div>

  <div class="section">
    <h2>Export Confirmation</h2>
    <p>
      I exported my database from phpMyAdmin as <code>lab04.sql</code> and saved it in:
      <code>C:\winter3363\lab04\lab04.sql</code>.
    </p>
  </div>

</body>
</html>
